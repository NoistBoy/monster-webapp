                        <!-- Off canvas -->
                        <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
                            <div class="offcanvas-header">
                                <h5 class="offcanvas-title" id="offcanvasExampleLabel">Dashboard</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>
                            <div class="offcanvas-body">
                            <div>
                                <div class="row">
                                    <div class="col-md-12 col-12 sideBar-wrapper sidebar-open">
                                        <div class="row bg-primary-red-light" style="border-radius: 20px; height: 650px;">
                                            <div class="col-12 px-4 py-5">
                                                @include('user-dashboard-menus')
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            </div>
                        </div>
                        <!-- Off canvas End-->
