<div class="row">
    <div class="col-md-12 col-sm-12 py-5">
        <div class="mb-5">
            {{-- <img src="{{ asset('asset/img/Asset 1-8.png') }}" alt="image" srcset="" class="w-100 img-fluid custom-object-fit"> --}}
            <img src="{{ asset('asset/img/VAPE-BANNER.png') }}" alt="image" srcset="" class="w-100 img-fluid custom-object-fit">
        </div>
        <div id="tags-products-section">
            {{-- {!! $ShopNowSection !!} --}}
        </div>

    </div>
</div>
