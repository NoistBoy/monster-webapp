<div class="row">
    <div class="col-12" id="whats-new-products-section">
      {{-- <div class=" container-fluid">
          <!-- owl-carousel start -->
          <div class="p-3 mt-5 product-section-wrapper" style="border-radius: 21px;">
            <h2 class="fw-bold fs-1 mb-3 mt-2 px-3 section-heading" >What's New </h2>
            <div class="owl-carousel owl-theme ">
                {!! $whatsNew_section !!}
            </div>
        </div>
      </div> --}}
    </div>
  </div>
