<div class="col-md-2 col-12 sideBar-wrapper sidebar-open d-none-sm">
    <div class="row bg-primary-red-light shadow" style="border-radius: 20px; height:100%;">
        <div class="col-12 px-4 py-5">
            @include('user-dashboard-menus')
        </div>
    </div>
</div>
